import os
import torch
import torch.nn.functional as F 
import numpy as np
import torchvision.transforms as transforms
from tqdm import tqdm

# device = 'cuda' if torch.cuda.is_available() else 'cpu'

def train(epoch, model, train_loader, criterion, optimizer, device):
    model.train()
    train_loss = 0
    correct = 0
    total = 0
    pbar = tqdm(train_loader)
    print(f'epoch : {epoch} _________________________________________________')
    for batch_idx, (inputs, targets) in enumerate(pbar):
        inputs, targets = inputs.to(device), targets.to(device)
        optimizer.zero_grad()
        outputs = model(inputs)
        loss = criterion(outputs, targets)
        loss.backward()
        optimizer.step()

        train_loss += loss.item()
        _, predicted = outputs.max(1)
        total += targets.size(0)
        correct += predicted.eq(targets).sum().item()
        pbar.set_postfix({'loss':train_loss/len(train_loader), 'acc':100*correct/total})

def test(epoch, model, test_loader, criterion, save_path, sign, device):
    model.eval()
    test_loss = 0
    correct = 0
    total = 0
    with torch.no_grad():
        pbar = tqdm(test_loader)
        for batch_idx, (inputs, targets) in enumerate(pbar):
            inputs, targets = inputs.to(device), targets.to(device)
            outputs = model(inputs)
            loss = criterion(outputs, targets)

            test_loss += loss.item()
            _, predicted = outputs.max(1)
            total += targets.size(0)
            correct += predicted.eq(targets).sum().item()
            pbar.set_postfix({'loss':test_loss/len(test_loader), 'acc':100*correct/total})
        acc = 100*correct/total
        if not os.path.isdir(os.path.join(save_path,sign)):
            os.mkdir(os.path.join(save_path,sign))
        torch.save(model.state_dict(), os.path.join(save_path,sign,'model.pt'))
    return acc

def test_eval(epoch, model, test_loader, criterion, save_path, sign, best_acc, device):
    model.eval()
    test_loss = 0
    correct = 0
    total = 0
    with torch.no_grad():
        pbar = tqdm(test_loader)
        for batch_idx, (inputs, targets) in enumerate(pbar):
            inputs, targets = inputs.to(device), targets.to(device)
            outputs = model(inputs)
            loss = criterion(outputs, targets)

            test_loss += loss.item()
            _, predicted = outputs.max(1)
            total += targets.size(0)
            correct += predicted.eq(targets).sum().item()
            pbar.set_postfix({'loss':test_loss, 'acc':100*correct/total})
        acc = 100*correct/total
    return acc

def query_algorithm(model, ulbl_loader, ulbl_idx, sign, device, K):
    model.eval()
    
    if sign=='high_conf':
        conf_list = torch.tensor([]).to(device)
        with torch.no_grad():
            pbar = tqdm(ulbl_loader)
            for i, (inputs, _) in enumerate(pbar):
                inputs = inputs.to(device)
                outputs = model(inputs)
                confidence = torch.max(F.softmax(outputs, dim=1),dim=1)
                conf_list = torch.cat((conf_list,confidence.values),0)
            arg = conf_list.argsort().cpu().numpy()
        return list(arg[-K:])
    
    if sign=='low_conf':
        conf_list = torch.tensor([]).to(device)
        with torch.no_grad():
            pbar = tqdm(ulbl_loader)
            for i, (inputs, _) in enumerate(pbar):
                inputs = inputs.to(device)
                outputs = model(inputs)
                confidence = torch.max(F.softmax(outputs, dim=1),dim=1)
                conf_list = torch.cat((conf_list,confidence.values),0)
            arg = conf_list.argsort().cpu().numpy()
        return list(arg[:K])
    
    if sign=='balance':
        arg = conf_list.argsort().cpu().numpy()
        l = []
        for i in range(0, len(ulbl_idx), len(ulbl_idx)//K):
            l.append(i)
        return list(arg[l])
    
    if sign=='random':
        return list(np.random.randint(0, len(ulbl_idx), size=K))
    
    if sign=='high_entropy':
        entr_list = torch.tensor([]).to(device)
        with torch.no_grad():
            pbar = tqdm(ulbl_loader)
            for i, (inputs, _) in enumerate(pbar):
                inputs = inputs.to(device)
                outputs = model(inputs)
                outputs = F.softmax(outputs, dim=1)
                entropy = -outputs*outputs.log()
                entropy = entropy.sum(dim=1)
                entr_list = torch.cat((entr_list,entropy),0)
            arg = entr_list.argsort().cpu().numpy()
        return list(arg[-K:])
    
    else:
        raise Exception('invalid sign')
            
def get_rand_augment(dataset):
    if dataset == 'cifar10':
        mean = (0.4914, 0.4822, 0.4465)
        std = (0.2023, 0.1994, 0.2010)
        size = 32
    elif dataset == 'stl10':
        mean = (0.4408, 0.4279, 0.3867)
        std = (0.2682, 0.2610, 0.2686)
        size = 96
    else:
        mean = (0.5071, 0.4867, 0.4408)
        std = (0.2675, 0.2565, 0.2761)
        size = 32

    normalize = transforms.Normalize(mean=mean, std=std)
    train_transform = transforms.Compose([
        transforms.RandomHorizontalFlip(),
        transforms.RandomCrop(size=size, padding=int(size*0.125), padding_mode='reflect'),
        transforms.ToTensor(),
        normalize,
    ])
    return train_transform

def get_test_augment(dataset):
    if dataset == 'cifar10':
        mean = (0.4914, 0.4822, 0.4465)
        std = (0.2023, 0.1994, 0.2010)
    elif dataset == 'stl10':
        mean = (0.4408, 0.4279, 0.3867)
        std = (0.2682, 0.2610, 0.2686)
    else:
        mean = (0.5071, 0.4867, 0.4408)
        std = (0.2675, 0.2565, 0.2761)
    
    normalize = transforms.Normalize(mean=mean, std=std)
    test_transform = transforms.Compose([
        transforms.ToTensor(),
        normalize,
    ])
    return test_transform